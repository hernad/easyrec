To get the Mediawiki Plugin to run

1. extract the "easyrecMediaWiki.php" to your Wiki's /extensions/ directory 

2. paste the configuration settings provided by easyrec.org 
   to your Wiki's /LocalSettings.php file.
